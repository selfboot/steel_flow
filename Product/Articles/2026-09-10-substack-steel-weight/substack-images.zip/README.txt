01 calculation: after the 108 metres flat bar paragraph.
02 feature overview: after the SteelFlow workflow paragraph.
03 PDF preview: after the feature overview caption.
Upload each image into Substack. Remove [IMAGE] markers before publishing. Keep the original captions.
